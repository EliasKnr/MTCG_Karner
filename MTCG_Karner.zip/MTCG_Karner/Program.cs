﻿using MTCG_Karner.Controller;
using MTCG_Karner.Server;

namespace MTCG_Karner
{
    internal class Program
    {
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // entry point                                                                                                      //
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        
        /// <summary>Main entry point.</summary>
        /// <param name="args">Arguments.</param>
        static void Main(string[] args)
        {
            HttpSvr svr = new();
            svr.Incoming += _ProcessMessage;

            svr.Run();
        }


        /// <summary>Event handler for incoming server requests.</summary>
        /// <param name="sender">Sender.</param>
        /// <param name="e">Event arguments.</param>
        private static void _ProcessMessage(object sender, HttpSvrEventArgs e)
        {
            UserController _userController = new UserController();
            PackageController _packageController = new PackageController();
            
            if (e.Path.StartsWith("/users") && e.Method.Equals("POST"))
            {
                _userController.CreateUser(e);
                
                
            }
            else if (e.Path.StartsWith("/sessions") && e.Method.Equals("POST"))
            {
                _userController.LoginUser(e);
            }
            else if (e.Path.StartsWith("/packages") && e.Method.Equals("POST"))
            {
                // Here you should check the Authorization header value
                string authHeader = e.Headers.FirstOrDefault(h => h.Name.Equals("Authorization")).Value;
                if (authHeader == "Bearer admin-mtcgToken") // ### replace with real token validation
                {
                    // Call the method to handle package creation
                    _userController.CreatePackage(e);
                }
                else
                {
                    e.Reply(403, "Forbidden: Invalid token");
                }
            }
            else if (e.Path.StartsWith("/transactions/packages") && e.Method.Equals("POST"))
            {
                _packageController.AcquirePackage(e);
            }




            //Console.WriteLine(e.PlainMessage);
            //e.Reply(200, "Yo! Understood.");
        }
    }
}