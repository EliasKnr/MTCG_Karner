using MTCG_Karner.Models;
using Npgsql;

namespace MTCG_Karner.Database.Repository;

public class PackageRepository
{
    public void CreatePackage(List<Card> packageCards)
    {
        if (packageCards.Count != 5)
            throw new ArgumentException("A package must contain exactly 5 cards.");

        using (var conn = new NpgsqlConnection(DBAccess.ConnectionString))
        {
            conn.Open();
            using (var transaction = conn.BeginTransaction())
            {
                try
                {
                    // Insert cards and get their IDs
                    List<Guid> cardIds = new List<Guid>();
                    foreach (var card in packageCards)
                    {
                        string insertCardQuery =
                            "INSERT INTO cards (id, name, damage, owner_id) VALUES (@Id, @Name, @Damage, @OwnerId) RETURNING id";
                        var cmd = new NpgsqlCommand(insertCardQuery, conn);
                        cmd.Parameters.AddWithValue("@Id", card.Id);
                        cmd.Parameters.AddWithValue("@Name", card.Name);
                        cmd.Parameters.AddWithValue("@Damage", card.Damage);
                        cmd.Parameters.AddWithValue("@OwnerId", DBNull.Value); // Or use a specific admin ID
                        cardIds.Add((Guid)cmd.ExecuteScalar());
                    }

                    // Insert package with card references
                    string insertPackageQuery =
                        "INSERT INTO packages (card_id1, card_id2, card_id3, card_id4, card_id5) VALUES (@CardId1, @CardId2, @CardId3, @CardId4, @CardId5)";
                    var packageCmd = new NpgsqlCommand(insertPackageQuery, conn);
                    for (int i = 1; i <= 5; i++)
                    {
                        packageCmd.Parameters.AddWithValue($"@CardId{i}", cardIds[i - 1]);
                    }

                    packageCmd.ExecuteNonQuery();

                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }
    }


    public void AcquirePackageForUser(User user)
    {
        using (var conn = new NpgsqlConnection(DBAccess.ConnectionString))
        {
            conn.Open();
            using (var transaction = conn.BeginTransaction())
            {
                try
                {
                    // Fetch a random package
                    string selectRandomPackageQuery =
                        "SELECT id, card_id1, card_id2, card_id3, card_id4, card_id5 FROM packages ORDER BY RANDOM() LIMIT 1";
                    var cmd = new NpgsqlCommand(selectRandomPackageQuery, conn);
                    int packageId;
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (!reader.Read())
                            throw new Exception("No packages available.");

                        packageId = reader.GetInt32(reader.GetOrdinal("id"));

                        // Transfer ownership of cards
                        for (int i = 1; i <= 5; i++)
                        {
                            string updateCardOwnerQuery = "UPDATE cards SET owner_id = @OwnerId WHERE id = @CardId";
                            using (var updateCmd = new NpgsqlCommand(updateCardOwnerQuery, conn))
                            {
                                updateCmd.Parameters.AddWithValue("@OwnerId", user.Id);
                                updateCmd.Parameters.AddWithValue("@CardId",
                                    reader.GetGuid(reader.GetOrdinal($"card_id{i}")));
                                updateCmd.ExecuteNonQuery();
                            }
                        }
                    }

                    // Remove the acquired package
                    string deletePackageQuery = "DELETE FROM packages WHERE id = @PackageId";
                    cmd = new NpgsqlCommand(deletePackageQuery, conn);
                    cmd.Parameters.AddWithValue("@PackageId", packageId);
                    cmd.ExecuteNonQuery();

                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }
    }
}