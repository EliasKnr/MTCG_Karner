namespace MTCG_Karner.Database;

public class DBAccess
{




    public const string ConnectionString =
        "Host=127.0.0.1;Port=5432;Username=postgres;Password=pw#inter;Database=mtcg_data";


}