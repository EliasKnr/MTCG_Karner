namespace MTCG_Karner.Models;

public class Card
{
    public Guid Id { get; set; }
    public string Name { get; set; }
    public double Damage { get; set; }
}
